Cufon.replace('#menu a, footer, h2, .button1, .date, .tabs .nav li a', { fontFamily: 'Ubuntu', hover:true });


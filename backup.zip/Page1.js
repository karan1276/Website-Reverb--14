function move1()
{
	document.getElementById("box1").style.zIndex="200000";
	document.getElementById("box1").style.visibility="visible";
	document.getElementById("white1").style.visibility="visible";
	document.getElementById("tab1").style.visibility="visible";
	document.getElementById("div11").style.visibility="visible";
	document.getElementById("box1").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box1").style.opacity="1";
	document.getElementById("white1").style.transition="width 1s ease";
	document.getElementById("white1").style.webkitTransition="width 0.8s ease";
	document.getElementById("white1").style.width="810px";
	document.getElementById("tab1").style.transition="opacity 1s linear 0.7s";
	document.getElementById("tab1").style.opacity="1";
	document.getElementById("title1").style.transition="opacity 1s linear 0.7s";
	document.getElementById("title1").style.opacity="1";
	document.getElementById("x1").style.transition="opacity 0s linear 0.7s";
	document.getElementById("x1").style.opacity="1";
	document.getElementById("box2").style.visibility="hidden";
	document.getElementById("white2").style.visibility="hidden";
	document.getElementById("tab2").style.visibility="hidden";
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("box3").style.visibility="hidden";
	document.getElementById("white3").style.visibility="hidden";
	document.getElementById("tab3").style.visibility="hidden";
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("box4").style.visibility="hidden";
	document.getElementById("white4").style.visibility="hidden";
	document.getElementById("tab4").style.visibility="hidden";
	document.getElementById("div14").style.visibility="hidden";
}
function move2()
{
	document.getElementById("box2").style.zIndex="200000";
	document.getElementById("box2").style.visibility="visible";
	document.getElementById("white2").style.visibility="visible";
	document.getElementById("tab2").style.visibility="visible";
	document.getElementById("div12").style.visibility="visible";
	document.getElementById("box2").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box2").style.opacity="1";
	document.getElementById("white2").style.transition="width 1s ease,height 1s ease";
	document.getElementById("white2").style.webkitTransition="width 0.8s ease,height 1s ease";
	document.getElementById("white2").style.width="810px";
	document.getElementById("white2").style.height="480px";
	document.getElementById("tab2").style.transition="opacity 1s linear 0.8s";
	document.getElementById("tab2").style.opacity="1";
	document.getElementById("title2").style.transition="opacity 1s linear 0.8s";
	document.getElementById("title2").style.opacity="1";
	document.getElementById("x2").style.transition="opacity 0s linear 0.7s";
	document.getElementById("x2").style.opacity="1";
	document.getElementById("box1").style.visibility="hidden";
	document.getElementById("white1").style.visibility="hidden";
	document.getElementById("tab1").style.visibility="hidden";
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("box3").style.visibility="hidden";
	document.getElementById("white3").style.visibility="hidden";
	document.getElementById("tab3").style.visibility="hidden";
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("box4").style.visibility="hidden";
	document.getElementById("white4").style.visibility="hidden";
	document.getElementById("tab4").style.visibility="hidden";
	document.getElementById("div14").style.visibility="hidden";
}
function move3()
{
	document.getElementById("box3").style.zIndex="200000";
	document.getElementById("box3").style.visibility="visible";
	document.getElementById("white3").style.visibility="visible";
	document.getElementById("tab3").style.visibility="visible";
	document.getElementById("div13").style.visibility="visible";
	document.getElementById("box3").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box3").style.opacity="1";
	document.getElementById("white3").style.transition="width 1s ease,height 1s ease";
	document.getElementById("white3").style.webkitTransition="width 0.8s ease,height 1s ease";
	document.getElementById("white3").style.width="810px";
	document.getElementById("white3").style.height="480px";
	document.getElementById("tab3").style.transition="opacity 1s linear 0.8s";
	document.getElementById("tab3").style.opacity="1";
	document.getElementById("title3").style.transition="opacity 1s linear 0.8s";
	document.getElementById("title3").style.opacity="1";
	document.getElementById("x3").style.transition="opacity 0s linear 0.7s";
	document.getElementById("x3").style.opacity="1";
	document.getElementById("box2").style.visibility="hidden";
	document.getElementById("white2").style.visibility="hidden";
	document.getElementById("tab2").style.visibility="hidden";
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("box1").style.visibility="hidden";
	document.getElementById("white1").style.visibility="hidden";
	document.getElementById("tab1").style.visibility="hidden";
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("box4").style.visibility="hidden";
	document.getElementById("white4").style.visibility="hidden";
	document.getElementById("tab4").style.visibility="hidden";
	document.getElementById("div14").style.visibility="hidden";
}
function move4()
{
	document.getElementById("box4").style.zIndex="200000";
	document.getElementById("box4").style.visibility="visible";
	document.getElementById("white4").style.visibility="visible";
	document.getElementById("tab4").style.visibility="visible";
	document.getElementById("div14").style.visibility="visible";
	document.getElementById("box4").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box4").style.opacity="1";
	document.getElementById("white4").style.transition="width 1s ease";
	document.getElementById("white4").style.webkitTransition="width 0.8s ease";
	document.getElementById("white4").style.width="810px";
	document.getElementById("tab4").style.transition="opacity 1s linear 0.7s";
	document.getElementById("tab4").style.opacity="1";
	document.getElementById("title4").style.transition="opacity 1s linear 0.7s";
	document.getElementById("title4").style.opacity="1";
	document.getElementById("x4").style.transition="opacity 0s linear 0.7s";
	document.getElementById("x4").style.opacity="1";
	document.getElementById("box2").style.visibility="hidden";
	document.getElementById("white2").style.visibility="hidden";
	document.getElementById("tab2").style.visibility="hidden";
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("box3").style.visibility="hidden";
	document.getElementById("white3").style.visibility="hidden";
	document.getElementById("tab3").style.visibility="hidden";
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("box1").style.visibility="hidden";
	document.getElementById("white1").style.visibility="hidden";
	document.getElementById("tab1").style.visibility="hidden";
	document.getElementById("div11").style.visibility="hidden";
}
function open11()
{
	document.getElementById("div11").style.visibility="visible";
	document.getElementById("div21").style.visibility="hidden";
	document.getElementById("div31").style.visibility="hidden";
	document.getElementById("div41").style.visibility="hidden";
}
function open21()
{
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("div21").style.visibility="visible";
	document.getElementById("div31").style.visibility="hidden";
	document.getElementById("div41").style.visibility="hidden";
}
function open31()
{
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("div21").style.visibility="hidden";
	document.getElementById("div31").style.visibility="visible";
	document.getElementById("div41").style.visibility="hidden";
}
function open41()
{
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("div21").style.visibility="hidden";
	document.getElementById("div31").style.visibility="hidden";
	document.getElementById("div41").style.visibility="visible";
}
function open12()
{
	document.getElementById("div12").style.visibility="visible";
	document.getElementById("div22").style.visibility="hidden";
	document.getElementById("div32").style.visibility="hidden";
	document.getElementById("div42").style.visibility="hidden";
}
function open22()
{
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("div22").style.visibility="visible";
	document.getElementById("div32").style.visibility="hidden";
	document.getElementById("div42").style.visibility="hidden";
}
function open32()
{
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("div22").style.visibility="hidden";
	document.getElementById("div32").style.visibility="visible";
	document.getElementById("div42").style.visibility="hidden";
}
function open42()
{
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("div22").style.visibility="hidden";
	document.getElementById("div32").style.visibility="hidden";
	document.getElementById("div42").style.visibility="visible";
}
function open13()
{
	document.getElementById("div13").style.visibility="visible";
	document.getElementById("div23").style.visibility="hidden";
	document.getElementById("div33").style.visibility="hidden";
	document.getElementById("div43").style.visibility="hidden";
}
function open23()
{
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("div23").style.visibility="visible";
	document.getElementById("div33").style.visibility="hidden";
	document.getElementById("div43").style.visibility="hidden";
}
function open33()
{
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("div23").style.visibility="hidden";
	document.getElementById("div33").style.visibility="visible";
	document.getElementById("div43").style.visibility="hidden";
}
function open43()
{
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("div23").style.visibility="hidden";
	document.getElementById("div33").style.visibility="hidden";
	document.getElementById("div43").style.visibility="visible";
}
function open14()
{
	document.getElementById("div14").style.visibility="visible";
	document.getElementById("div24").style.visibility="hidden";
	document.getElementById("div34").style.visibility="hidden";
	document.getElementById("div44").style.visibility="hidden";
}
function open24()
{
	document.getElementById("div14").style.visibility="hidden";
	document.getElementById("div24").style.visibility="visible";
	document.getElementById("div34").style.visibility="hidden";
	document.getElementById("div44").style.visibility="hidden";
}
function open34()
{
	document.getElementById("div14").style.visibility="hidden";
	document.getElementById("div24").style.visibility="hidden";
	document.getElementById("div34").style.visibility="visible";
	document.getElementById("div44").style.visibility="hidden";
}
function open44()
{
	document.getElementById("div14").style.visibility="hidden";
	document.getElementById("div24").style.visibility="hidden";
	document.getElementById("div34").style.visibility="hidden";
	document.getElementById("div44").style.visibility="visible";
}
function hide1()
{
	document.getElementById("box1").style.visibility="hidden";
	document.getElementById("white1").style.visibility="hidden";
	document.getElementById("tab1").style.visibility="hidden";
	document.getElementById("div11").style.visibility="hidden";
	document.getElementById("div21").style.visibility="hidden";
	document.getElementById("div31").style.visibility="hidden";
	document.getElementById("div41").style.visibility="hidden";
	document.getElementById("box1").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box1").style.opacity="0";
	document.getElementById("white1").style.transition="width 1s ease";
	document.getElementById("white1").style.webkitTransition="width 0.8s ease";
	document.getElementById("white1").style.width="0px";
	document.getElementById("tab1").style.transition="opacity 0s ease";
	document.getElementById("tab1").style.opacity="0";
	document.getElementById("title1").style.transition="opacity 0s ease";
	document.getElementById("title1").style.opacity="0";
	document.getElementById("x1").style.transition="opacity 0s linear";
	document.getElementById("x1").style.opacity="0";
}
function hide2()
{
	document.getElementById("box2").style.visibility="hidden";
	document.getElementById("white2").style.visibility="hidden";
	document.getElementById("tab2").style.visibility="hidden";
	document.getElementById("div12").style.visibility="hidden";
	document.getElementById("div22").style.visibility="hidden";
	document.getElementById("div32").style.visibility="hidden";
	document.getElementById("div42").style.visibility="hidden";
	document.getElementById("box2").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box2").style.opacity="0";
	document.getElementById("white2").style.transition="width 1s ease,height 1s ease";
	document.getElementById("white2").style.webkitTransition="width 0.8s ease,height 1s ease";
	document.getElementById("white2").style.width="0px";
	document.getElementById("white2").style.height="0px";
	document.getElementById("tab2").style.transition="opacity 0s ease";
	document.getElementById("tab2").style.opacity="0";
	document.getElementById("title2").style.transition="opacity 0s ease";
	document.getElementById("title2").style.opacity="0";
	document.getElementById("x2").style.transition="opacity 0s ease";
	document.getElementById("x2").style.opacity="0";
}
function hide3()
{
	document.getElementById("box3").style.visibility="hidden";
	document.getElementById("white3").style.visibility="hidden";
	document.getElementById("tab3").style.visibility="hidden";
	document.getElementById("div13").style.visibility="hidden";
	document.getElementById("div23").style.visibility="hidden";
	document.getElementById("div33").style.visibility="hidden";
	document.getElementById("div43").style.visibility="hidden";
	document.getElementById("box3").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box3").style.opacity="0";
	document.getElementById("white3").style.transition="width 1s ease,height 1s ease";
	document.getElementById("white3").style.webkitTransition="width 0.8s ease,height 1s ease";
	document.getElementById("white3").style.width="0px";
	document.getElementById("white3").style.height="0px";
	document.getElementById("tab3").style.transition="opacity 0s ease";
	document.getElementById("tab3").style.opacity="0";
	document.getElementById("title3").style.transition="opacity 0s ease";
	document.getElementById("title3").style.opacity="0";
	document.getElementById("x3").style.transition="opacity 0s ease";
	document.getElementById("x3").style.opacity="0";
}
function hide4()
{
	document.getElementById("box4").style.visibility="hidden";
	document.getElementById("white4").style.visibility="hidden";
	document.getElementById("tab4").style.visibility="hidden";
	document.getElementById("div14").style.visibility="hidden";
	document.getElementById("div24").style.visibility="hidden";
	document.getElementById("div34").style.visibility="hidden";
	document.getElementById("div44").style.visibility="hidden";
	document.getElementById("box4").style.background="rgba(0,0,0,0.7)";
	document.getElementById("box4").style.opacity="0";
	document.getElementById("white4").style.transition="width 1s ease";
	document.getElementById("white4").style.webkitTransition="width 0.8s ease";
	document.getElementById("white4").style.width="0px";
	document.getElementById("tab4").style.transition="opacity 0s ease";
	document.getElementById("tab4").style.opacity="0";
	document.getElementById("title4").style.transition="opacity 0s ease";
	document.getElementById("title4").style.opacity="0";
	document.getElementById("x4").style.transition="opacity 0s linear";
	document.getElementById("x4").style.opacity="0";
}
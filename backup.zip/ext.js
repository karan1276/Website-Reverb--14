$(document).ready(function(){
	$('#countdown').countdown( {date: '07 Mar 2014 00:00:00'} );
});